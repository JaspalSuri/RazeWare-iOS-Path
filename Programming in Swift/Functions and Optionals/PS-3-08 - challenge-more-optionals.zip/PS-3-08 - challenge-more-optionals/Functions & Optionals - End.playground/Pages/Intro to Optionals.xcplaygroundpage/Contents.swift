//: [Previous](@previous)
//: # Intro to Optionals

var catName: String?
catName = "Princess Ozma"
print(catName)
catName = nil

//: [Next](@next)
