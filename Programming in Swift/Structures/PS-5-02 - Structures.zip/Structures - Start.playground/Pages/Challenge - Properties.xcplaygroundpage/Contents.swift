//: [Previous](@previous)
/*:
 # Challenge Time - Properties!
 
 Create a struct named `Temperature` with properties for degrees in both Celsius and Fahrenheit, as `Double`s.
 * _Hint 1_: One property must be stored, but the other can be computed. They should always stay in sync.
 * _Hint 2_: To convert from Fahrenheit to Celsius, subtract 32, then divide by 1.8.
 */


// TODO: Write solution here


//: Modify the Fahrenheit property to print out a warning message if it is set to above 100 degrees.

//: [Next](@next)
